// เปิดข้อมูลเพิ่มเติมของคนขับ
function more_info(){
  document.querySelector('.detail-more').classList.add('show')
}
// ปิดกล่องข้อมูลเพิ่มเติม
function close_info(){
  document.querySelector('.detail-more').classList.remove('show')
}