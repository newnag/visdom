// เปิดหน้าเพิ่ม
function open_addCode(){
  document.querySelector('.modal-add-type').classList.add('show')
}
// ปิดหน้าเพิ่ม
function close_addJob(){
  document.querySelector('.modal-add-type').classList.remove('show')
}